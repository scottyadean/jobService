<?php

class Default_Bootstrap extends Zend_Application_Module_Bootstrap
{

}

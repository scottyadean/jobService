<?php

class Default_Model_Program extends Zend_Db_Table_Abstract {

    protected $_name = 'providers_programs';
    protected $_primary = 'id';
    protected $_dependentTables = array( 'Default_Model_ProgramLocations');
    
    protected $_current;
    
    public $page_limit = null;
    public $page_offset = 0;
    
    public $order_by;
    
    
    public function getProgramLocations() {
    return $this->_current->findManyToManyRowset(
            'Default_Model_Locations','Default_Model_ProgramLocations')->toArray();    
    }
    
    
    public function _index($where = array()) {
    
        $select = $this->select()->from($this->_name)
                                 ->setIntegrityCheck(false)->joinLeft(array('i'=>'industries'),
                                 $this->_name.'.industry_id = i.id', array('name AS industry_name','id AS industry_id'));
        
        
        if(!empty($where) && is_array($where) ) {
            foreach($where as $k=>$v){
                $select->where("{$k}", $v);
            }
        }
        
        if( !empty($this->page_limit)  ) {
            $select->limit($this->page_limit, $this->page_offset);
        }
        
        
        if(!empty($this->order_by)) {
            $select->order($this->order_by);    
        }
    
        return $this->fetchAll($select);
    }

    
    public function _create($data) {
        return $this->insert($data);
    }
    
    public function findById($id) {
       $this->_current = $this->find($id)->current();
       return $this->_current;
    }

    public function _read($id) {
        $this->_current = $this->find($id)->current();
        return $this->_current;
    }
    
    public function _update($data) {
        $data['modifed'] = new Zend_Db_Expr('NOW()');
        return $this->update($data, array('id = ?' => (int)$data['id']));
    }
    
    public function _search($value, $field = 'name') {
       $select = $this->select()->where("{$field} = ?", $value);
       return $this->fetchRow($select);
    }

    public function _count($where = null) {
       
       $select = $this->select();
        
        if( !empty($where) && is_array($where) ) {
            foreach($where as $k=>$v){
                $select->where("{$k}", $v);
            }
        }
       
       $select->from($this->_name,'COUNT(id) AS num');
       return (int)$this->fetchRow($select)->num;
    }

}


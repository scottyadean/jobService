<?php
class Default_Model_Provider extends Zend_Db_Table_Abstract {

    protected $_name = 'providers';
    protected $_primary = 'id';
    
    public $page_limit = null;
    public $page_offset = 0;
    
    public $order_by;
        
    public function _index($where = array()) {
        
         $select = $this->select()->from($this->_name)
                 ->setIntegrityCheck(false)->joinLeft(array('i'=>'industries'),
                             $this->_name.'.industry_id = i.id', array('name AS industry_name','id AS industry_id'));
        
        if(!empty($where) && is_array($where) ) {
            foreach($where as $k=>$v){
                $select->where("{$k}", $v);
            }
        }
        
       if( !empty($this->page_limit)  ) {
            $select->limit($this->page_limit, $this->page_offset);
        }
        
        if(!empty($this->order_by)){
                $select->order($this->order_by);    
        }
        
        return $this->fetchAll($select);
    }

    public function all($regExp = false) {
        /*
      ->setIntegrityCheck(false)->join(array('i'=>'industries'),
                          $this->_name.'.industry_id = i.id', array('name AS industry_name','id AS industry_id'))  
          */
          //
          
          $select = $this->select()->from(array('providers'=>$this->_name))->setIntegrityCheck(false)
                         ->joinLeft(array('i'=>'industries'),
                             'providers.industry_id = i.id', array('name AS industry_name','id AS industry_id'))
                         ->order($this->_name.'.name ASC');
        
           $select->where($this->_name.'.visible = ?', 'Y'); 
        
        
        if($regExp != false) {          
            $select->where($this->_name.".name REGEXP '^[".$regExp."]'");
        }
        
        return $this->fetchAll($select);
        
     }   
    
    public function findbyField($val, $field = 'name', $regEx = 'starts') {
        
        $field = trim($field);
        if(empty($field)) {
            $field = 'name';    
        }
        
        if( $regEx == 'starts' ) {
            $val = "$val%";
            $opt = 'LIKE';
        }
        
        if( $regEx == 'contains' ) {
            $val = "%$val%";
            $opt = 'LIKE';
        }
        
        if( $regEx == 'equals' ) {
            $val = "%$val%";
            $opt = '=';
        }
        
        if(empty($opt)) {
            $val = "%$val%";
            $opt = 'LIKE';
        }
       
       $select = $this->select()->where($field." ".$opt." ?", "$val");
       
       //print $select->__toString();
       //return array();
       return $this->fetchAll($select)->toArray();
    }

    
    public function _create($data) {
        return $this->insert($data);
    }
    
    public function _read($id) {
        return $this->find($id)->current();
    }
    
    public function _update($data) {
        $data['modifed'] = new Zend_Db_Expr('NOW()');
        return $this->update($data, array('id = ?' => (int)$data['id']));
    }
    
    public function _search($value, $field = 'name') {
       $select = $this->select()->where("{$field} = ?", $value);
       return $this->fetchRow($select);
    }

    public function _count($where = null) {
       
       $select = $this->select();
        
        if( !empty($where) && is_array($where) ) {
            foreach($where as $k=>$v){
                $select->where("{$k}", $v);
            }
        }
       
       $select->from($this->_name,'COUNT(id) AS num');
       return (int)$this->fetchRow($select)->num;
    }

}


<?php
class Default_IndexController extends Zend_Controller_Action
{

   public $id;
   public $xhr;
   public $uri;
   public $post;
   public $format;
   public $callback;
   
   protected $_model;
   
   public function init() {
    
        $this->id = $this->getRequest()->getParam('id', null);
        $this->xhr = $this->getRequest()->isXmlHttpRequest();
        $this->uri = $this->getRequest()->getRequestUri();
        
    }
    
    public function indexAction() {
          
    }
    
    
    public function pageAction() {
     $this->_model = new Default_Model_Page;
     $page = $this->_model->_read($this->id);
     $this->view->page = $page;
    }
    
    
    public function eventsAction() {
          
    }
    
    
  public function calendarAction() {
        
        if($this->xhr){
            $this->_helper->layout->disableLayout();
        }
        
        $this->view->year  = $this->getRequest()->getParam('year', date("Y"));
        $this->view->month = $this->getRequest()->getParam('month', date("n"));
        $this->view->day   = $this->getRequest()->getParam('day', date("d")); 
    }
        
    
        
    protected function _asJson(array $data) {
        $this->_helper->layout->disableLayout();
        $this->_helper->viewRenderer->setNoRender(true);
        
        $this->getResponse()->setHeader('Content-type', 'application/json')
                            ->setBody(json_encode($data));
    }   
}
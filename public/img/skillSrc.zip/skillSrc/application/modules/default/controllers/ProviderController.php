<?php
class Default_ProviderController extends Zend_Controller_Action {    
   
   
   public $id;
   public $xhr;
   public $uri;
   public $post;
   public $format;
   public $callback;
   
   protected $_model;
   
   public function init() {
    
        $this->id = $this->getRequest()->getParam('id', null);
        $this->xhr = $this->getRequest()->isXmlHttpRequest();
        $this->uri = $this->getRequest()->getRequestUri();
        $this->sort = $this->getRequest()->getParam('sort', false);
        $this->post = $this->getRequest()->isPost();
        $this->format = $this->getRequest()->getParam('format', false);
        $this->callback = $this->getRequest()->getParam('callback', null);
        $this->_model = new Default_Model_Provider;
        
    }
   
    public function indexAction() {
       
        $this->view->providersA_H = $this->_model->all('a-h')->toArray();
        $this->view->providersI_P = $this->_model->all('i-p')->toArray();
        $this->view->providersQ_Z = $this->_model->all('q-z')->toArray();
        $this->view->locations = $this->locations();
        
    }
    
    
    public function industryAction() {
        
        
        
        
    }
    
    public function searchAction() {
        
        if( $this->xhr ){ 
            $this->_helper->layout->disableLayout();
            $this->view->disableLayout = true;
        }else{     
            $this->view->disableLayout = false;
        }
        
        if($this->id == false) {
            $this->id = 'a';
        }
        
        
         $this->field = $this->getRequest()->getParam('field', 'name');
         $this->regex = $this->getRequest()->getParam('regex', 'starts');


        $this->view->providers = $this->_model->findbyField($this->id, $this->field, $this->regex );
        $this->view->locations = $this->locations();
       
    }
    
    public function viewAction() {
        
        if(empty($this->id)) {
            $this->_helper->flashMessenger->addMessage(array('alert alert-error'=> 'Error: no "provider id" params was sent to the view page.') );
            $this->_redirect("/providers");   
        }
        
        $this->view->provider = array_shift($this->_model->_index(array('providers.id = ?'=> $this->id))->toArray());
       
        $locations = new Default_Model_Locations;
        $this->view->locations = $locations->_index(array('provider_id = ?'=> $this->id))->toArray();
       
        $programsModel = new Default_Model_Program;
        $this->view->programs = $programsModel->_index(array('providers_programs.provider_id = ?'=> $this->id))->toArray();
   
        
    }
 
    
    public function locations(){
        
        
        $locations = new Default_Model_Crud;
        $locations->setTable("providers_locations");
        $addresses = $locations->_index()->toArray(); 
        
        foreach( $addresses as $key=>$address ) {
            
            if(!isset( $formated[$address['provider_id']])) {
                
                $formated[$address['provider_id']] = array();
            }
            
            $formated[$address['provider_id']][] = $address;
            
        }
        
        return $formated;
        
    }
    
  
}  
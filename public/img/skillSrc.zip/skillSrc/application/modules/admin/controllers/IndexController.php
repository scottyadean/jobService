<?php
class Admin_IndexController extends Zend_Controller_Action {


    public $model;
    
    public function init() {

    }


    public function indexAction() {
        $usr = new Default_Model_User;
        $this->view->users =  $usr->_count();
        $crud = new Default_Model_Crud;
        
        $crud->setDbName('pages');
        $this->view->pages = $crud->_count(array('id > ?'=>0));
        
        $provider = new Default_Model_Provider;
        $this->view->providers = $provider->_count();
    
    }
        
    
   
}

 


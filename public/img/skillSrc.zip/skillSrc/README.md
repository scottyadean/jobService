socialWorks
===========

A simple application using PHP, ZF, JQuery and Bootstrap to aid social workers in orginzation of clients and tasks

$(function(){
           
        $("#type_id-element").append(" <a href='/type/index/create' title='Add Type'><i class='icon-plus'></i></a>" );          
    }
 );
-- MySQL dump 10.13  Distrib 5.5.35, for debian-linux-gnu (x86_64)
--
-- Host: localhost    Database: skillSrc
-- ------------------------------------------------------
-- Server version	5.5.35-1ubuntu1

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `images`
--

DROP TABLE IF EXISTS `images`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `images` (
  `id` int(11) NOT NULL,
  `relation_id` int(11) DEFAULT NULL,
  `type` varchar(45) DEFAULT NULL,
  `ext` varchar(4) DEFAULT NULL,
  `img` longblob,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `images`
--

LOCK TABLES `images` WRITE;
/*!40000 ALTER TABLE `images` DISABLE KEYS */;
INSERT INTO `images` VALUES (0,6,'u','jpg','/9j/4AAQSkZJRgABAQEAYABgAAD//gA8Q1JFQVRPUjogZ2QtanBlZyB2MS4wICh1c2luZyBJSkcgSlBFRyB2ODApLCBxdWFsaXR5ID0gMTAwCv/bAEMAAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/bAEMBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAQEBAf/AABEIAJYAyAMBIgACEQEDEQH/xAAfAAABBQEBAQEBAQAAAAAAAAAAAQIDBAUGBwgJCgv/xAC1EAACAQMDAgQDBQUEBAAAAX0BAgMABBEFEiExQQYTUWEHInEUMoGRoQgjQrHBFVLR8CQzYnKCCQoWFxgZGiUmJygpKjQ1Njc4OTpDREVGR0hJSlNUVVZXWFlaY2RlZmdoaWpzdHV2d3h5eoOEhYaHiImKkpOUlZaXmJmaoqOkpaanqKmqsrO0tba3uLm6wsPExcbHyMnK0tPU1dbX2Nna4eLj5OXm5+jp6vHy8/T19vf4+fr/xAAfAQADAQEBAQEBAQEBAAAAAAAAAQIDBAUGBwgJCgv/xAC1EQACAQIEBAMEBwUEBAABAncAAQIDEQQFITEGEkFRB2FxEyIygQgUQpGhscEJIzNS8BVictEKFiQ04SXxFxgZGiYnKCkqNTY3ODk6Q0RFRkdISUpTVFVWV1hZWmNkZWZnaGlqc3R1dnd4eXqCg4SFhoeIiYqSk5SVlpeYmZqio6Slpqeoqaqys7S1tre4ubrCw8TFxsfIycrS09TV1tfY2dri4+Tl5ufo6ery8/T19vf4+fr/2gAMAwEAAhEDEQA/AP7+KKKKACiiigAooooAKKKKACiiigAopqOkiq8bK6MqujqQyOjgMrowJVlYHIYEgjkcVnW2r2V1qmpaMjsuo6VBp93dW8ihWNjqv2tbC+iwzbra4uNO1OzRm2P9p028QxhEjkkANOisrUdYtNMu9DsrliJvEOqTaRp4HRruDRdY151Y9l+waJesDg/MqjvV65ubezgmurqaG2tbaGW4ubm4lSG3t7eBDJNPPNIVjhhijVnkkdgiIpZmCgmgCeiobeeO6ghuId/lTxRzRGSKWGQxyoJELwzJHNE5VgWjlRJUJ2yIjgqJqACiiigAooooAKKKKACiiigAooooAKKKKACiiigAoor5g/ZE/a7+D37bvwh/4Xl8CbrxDqPw5m8ZeM/BWmat4k0OXw5d6xfeB9bn0HVdTstJup5NRg0i5vreVtNbVrfTdTlgAku9LsmKoQD6foormvFtn4hu9Duv+ETvrWx8S2m2+0VtSM39jXd9bZdNL11beG4nGi6qnmafqFxbW1xe6dFc/wBqabC+p2VmVALXiPUb3R9D1PVtP0u41u60y0mv00ez/wCP7U47RfPuLLTV2sJdVubdJYtLt5GhhudQa2t57m1hle5in0PWtK8SaNpPiHQr631TQ9e0yw1rRtUtHEtpqWlapaxX2n39rKOJLa7tJ4biCQcPFIrY5rhfh/8AFfw14/8ACF/4qgM2hTeG7zVtD8feHNaaGHXfh74r8ORpJ4m8L+KIIJJoYL7SEkhvYL21mudI8Q6Be6P4s8M3+r+Fte0PWNQ+MtY+P3hL9kDxp8WvhZ8T/FC+FfAvijQdU+OX7Mmvto2s+KJ9Wfxb4u0Twp8Qfgp4Y8MeG7DVPEfjfxd4T+Nnj/wdrHgXwV4a0691jXvC3xx8GeAfBei3a+Cb3ywaV/639D6t+DvigTzfFD4eX8oGqfCD4iaj4abe6xxP4R8SaTpPxH+H01hFJtuP7J0jwb4x03wS19Puiudd8F+IY4p5mtJimPa+Im0z9qrW/CV5JhfGv7PvhXxH4ejB2kt8LviN4x0vxm6g583YPi/4DR9u3yAyFy5uo9nw1pvxf/aN1H9o+D43eDP2AP2o9S+GvxN/Z4074efFbRvE+v8A7KngbUU8a+BvG/8AwkPwn1HSPDPxC/aP8M+JpdLj8PfFH446P45uta8NeHtWlNl8P7WPR9TiWaLQsq11f9tyT4wfswfFqX9inx8Z/g58C/jX8GPiJY6t8cv2c1v/ABc3xPk+AmuWOu6O9j8U9atVWLxX8DbG5vDql4t9aWOsXP2V72Uzw3IFuzWq6teT+Wu3/Dn3P8W/GNsnxN/Y703TbhZ4fGnxj8YXsciFvLu9D039mH49akZUwyMQ95caLMhkjkj2FtyLKI3TT/aT8Vw6b8HdZ0+yuI2ufiN4p8D/AANsZ4XEstpqHxj+I3h74PX2pW8cZLT3HhOHxTqPiG6hQOYYdBvJJ08q3mx+f6337cWofEb9lLxVrv7E3iAaP8ALP4qx+IoLT48fs/Xupa5c+LfBQ8E+EJdEjufGVlDEdK06a9XWJru/tXeOdhBHd+Ywii8W65+2n4h8Ufs3T6v+wz8Wr7wj8I/2hviR8dfiNZeH/jJ+ydfX/iyLxB4V+NOnfDzwx4btvEHx38L2s9t4M8V/FXQfE1/PrN5ojvc/D7T5dPkumm8icC22q180uu2++39I/X3U9T0/RdOv9Y1e+tNM0nSrG71LU9S1C5hs7DTtPsYHur2+vbu4eOC1s7S2iknubmZ0ighjeSRlRSRw3wn1zVfFngXRPGmrw3tlP43gPjCw0rUYZbS+0Pw94gY6h4U0TUdPmRW07WtM8Ly6Pb+JLJTJHH4lXWHSaZZBK/5cftBfH/44a/8AC258GfE79jf9q74YeAfH3xet/wDhfvji80z4MfFjRfCf7LGl+ILzVvF2n2/hf9m744fHPx3qUvj34X+FtG+GXi3TtE8LXNzpUvxD8XeLbSZ49HV5PvPxP+1P4B0j4MXHxs8MmP4g+HvEOuaV4T+Ctr4V1Szup/jn4v8AE97Y+HPBeg+Crlk+zonijxtdXGg22tXW/RbDQ9NvvH+oX0Pgy2uNVhAtb/h0+3b1PouLVbCfUrzSIbhJdR0+1sb29tkDlra21KS+isZJH2eUGuH0282RCQzBYhI8aRywvJoV5r8KPB2s+DfCUEHizVLTX/H2v3Uvif4i+IbCK4g03WPGuqw266q2iwXbSXtp4X0aG2s/DHgvT7+e7v8ASvBeheHtKvb2+ubKW8n3tE8Y6V4j1fX9N0MtqFr4Yu30jWNZgZG0uPxHCw+2+HbOcEi+1LRkwuv+T/o+k3ssWkSTS6vb6xY6SCOsoor5g/ak/a7+Dv7HmifCbxL8arrxDp2gfGP45+Bv2fPDWp6Bocuvx6d48+Ilj4ivPDM2v2lrOmo22gXEvhu50+61DTbPVbmzvLyweWwFg15e2YB9P0UUUAFFFFABRRRQAUUUUAFFFZHiDXtH8LaFrXibxDqFtpGgeHdJ1LXtc1a9fyrPS9G0ezm1DVNRu5MHy7axsrea5nfBKxRs2DigD8Tv2zv+ClyfC7/gqv8A8E5f2BvBGtrA/j/xj4j8Z/tCSWtyoA0Pxb8MPiX4K+Dfw+1D5ZIN2teMbz/hP9Q0+Yw6hBJ4a8BX1v8A6NqgaT8pv+CWv/BUT4V/sRfsy+Mf2J/Dvwj+Nf7TX7YvhD9rL9qLw74Y/Zm+A3gTVdZ8RNotp8RZ3tfE3i/xPLZJ4a8H+EF1G41Cyv8AVEfW9U0mKwkvbrw6umILsfN37SPg74i6j/wTq1//AILrQafBYftH+L/+Cl3wl/bZ8BnxPAs15of7OHw98Xar8Af2bfhLqNqZkn1HQYrbWPD3iC4trO4RtW8P6pbMyxxRzuPFfDC/8FavhZ+wx8GPCvws8NaR+w5r37ZHx08K/DeLxlqNq0P7d/7cX7QHx/8AFur+JvE3xE8XeJYNIstf+C3wg8G6Rc63faZrL2/hvxbo2h6ToUa6hq+meLpdYtw2UU1bpdJ3dryTbb7tJSt6K+h/Zj+yH4p/bR+N/wALfGniL9tP4QeB/wBlvxlqnjFp/hV8PvhT8RF+IHjTwH4Lj0XSp9Nu/iH4wjl1LwdrHjuPXpdUknsNN0oeFb3QxZaX4h8NXMNzqthdew+EPjVNpfj6z+CHxji07wv8UtUtb698A6zZxT2PgX44aNpUD3Wpaj8O5765vJLLxbodjG1741+FWo6jfeKPC9ss2s6Zd+LfBSweMrnwv4PeAfE37AHwU8A/CrS/Dvij46fBP4f6DHa61418KaXe638e9O1m+uLjW/G3xA8Z+B7aW/1D4yx+J/FGoa/4q17U/AJk+J8F1qNtp1r8O/iLfS6l4lg0fi9r/wAGP2lPgrc63ezQfGz9m3xHNbapB8SPgpqeo3fxH+CfjLwtdxvp3xA8NT+D3l8YaZ4i8AeIbR76XW/B32b4nfC7xNZCLUfCup6UPEN34XDLd7aX6L7u/wCd336nAfHnxT4m+DHirXf2t/hZ4c1jWdX+HOnaRo/7bf7O/h9W1PX/AB38HrOO7l0b4y/DvTVhtj4j+I/wp06LV9d8EarY2lnL8YPhlZ+MPhPrEC+P/CPgrSPh/wDJf7VfiH4PeLvCn7NGqDWNC8Y+EvA/7SP7IP7Y/wCwv8XNIvornR9e+F4/aF+E3hP40/Dix1aEeXPdeA/hh8R/EF9oWis1jFf/AA317wVcw2Gr6l8HvG+qWtbVP2hfiT8MfGPwr+HXxr+KfguP4jeInMH/AAT+/wCCiMbaWv7O/wC17oerxW+qQfs2/tOy+EX/ALA8G/EPxzYWtnCLnQ1g8JePdVs7H4qfBSPRfGmhj4fSfj3+2L8TPA37Pvwn+PXh/VPAvivw5+yrr3j3XviDpHweaVF+JH/BLz/gqF4R0nWPiTo3wzT+y0mhi/Zf/bCddYg8C+J/D8Unw21nSfiB4kuPD0vh3wn4m1EyhcVdq291bV6rRO3+XRXT1tf9w/22/wDgvx/wTu/YU+Ifib4O/EPxj4++JHxh8GPBB4s+HHwa8Et4k1Lw5f3dlb39tpmr+JfEuq+DvAMOpm1uoJLvTLbxbeajpZfydUtLO5xA348+Nv8Ag8T+DlhcXC/Dj9h/4meK7VWk+yzeNvjJ4W+H9xMoB8o3FtoXgj4lx2zOcCRY7u6EYJKtLgBv51P+Dg/wvD4X/wCCvX7XgswG0zxPqnwq8c6ZcoSYr638afA74a+Ibq7hY4LRtqt9qMWcAF4X2/JtJ/GKg2hSg4xbu7pPfuvKx/brH/weSzi4kaT/AIJ0xG0ZYxHEn7Wzi4jYE+a7zt+zQY5lbIMcS28BTDB5ZdwKe6/D/wD4PCv2b9SuYU+Kf7HXxt8GWbOonuPAPj3wJ8SriKM43vFa+Ibb4URzsvJCNdwBsD51zx/ArRQV7Kn2t83+rP8AVm+BH/BaX9hz9t/4OftCal+zr8R9YT4i/CT4B/En4ueI/hj8QvCmp+D/ABro/hXwv4duXuvEIjm+3eGNd0rT9SudNstUn8MeJtbGlz39gNSFomoWT3HgH7DPxE074n+DP2fvj0dLk134Hfs2fD3wV+x9/wAE8PhvZldOl/aA+PuhfDaL4e/G39oDRozbzW6+HdPtPDniz4V/DzxY0F5YeCvhF4Z+P3xQ1GOHw94lmNn/AB+/8ESLfSvDvgT/AIK1/FXXrptL0XQf+CZfxd+Fd9rqRyzvof8AwvDxT4Q8OrqVvbwQ3M0t7axaJcXNosFtPPI1u8EUMvntFJ/TX4e+P3i2/wBe0H4Ifs16boPwG+Mtj8DdO0bwnJ4zi03/AIVr/wAEdP8AgnHY2Gkzp8TPjWmp3g8Pv+2J8ePDmkaN4zn8BazqaXOhrB4B0LxpcWnh/wAAa/rPxBDCcFFtK7736aJvZef3abtH7T6r8UvHXxH+IN9+yn8HfF0+oeMPDEdlq37XH7QujrG2h/BFPElsmqW3ws+G1pcnULFPjX4u0yeD/hDvDV22pRfB74cy6f8AE74iy+IPEWqeDNF+JX2J4at/h78Ofh5p0Xh648P+Gvhp4U8O/abPUTqlvH4e03w5YWr3lxrN5r99dyQzWv2dZ9U1PxBqN/M967XOrajqFxPPPdSfjv4I+KP7O37NnwH+Hnh630/4gaF+zh4m1u/0/wCB3wxfTdb8V/tk/wDBS/4t67ctrXiX4i6l4OuBp/jjXvDPxD1u6m8S6zceKYtEk+JNvqaeI/ihdfDr4Dww+H/H32Z4C8H/ABB+KXijwp43/bCm0Pw5q91d2/iH4RfsceEdT/4Srwr8N4NLuYJ9P8ZfFzVNKhZfjH8StAvH064uNemsrb4I/CXxC2iweCrHV/F2l6X8V9fDNrTy6ee3r92iW2rvfmP2tv2hv23/AAZ4b+HvxS/Yl/Ze8H/tN+BrfU9fPxN+HnjTx1J8Ifit408MpaaZc6Hr/wAFLjXSukxQxiLxAZYPFuj3eteKII7O68LeHJdNfTtU178Hv28/+ClnwZ/4KE6v/wAE5/2U9F8A/GH4G/tO6V/wVY/ZF1j4x/s3fHz4eax4N+IPgXwjo0vjXT9b8QCWa2n8P674cF7rdlJa39pqEerSacEudS8OaYl/bI39Ev8AwUI+EPgr9oP9mLx/8Etf8fy/DTx344025m+BfjLQ9V1XTfH/AIX+NnhmB9f+H3ir4exeF2/4TfUNb8Pa7aWt1qtj4Lil1u98LSa7px2WF/eMf4rfGPxH/wCCr3xJ/YK8EftDePvAeg/tceK/2RvjmLzw58f9F0BLX9tP9hr4+fs0fEZW8a/D3456Zp+ly6r8V/hFrnh23N9r89tPdXgtfEejeM/iPrltL4ettDuAuCT6LR6a2eu2r91pa6aP12P6Z/8AgmN/wUvi/aW/bA/4KSfsZ+NdbW+8Y/s2ftM/Fy9+D9zc3Cy3Gv8AwQ03x9deCdb0q1cBnu4vhv49tkjW6eUpH4d8f+EtIsIjaaIZD+49fxA/swfD/Wv2Wf2GP+Cev/BZy6ENr43X9sn4tfEr9r+/0tkNtq37M37anxRm+EPjC91ySFnOqnwXc6D8OPFfh7T73KaNrWtahNJLa3Nk0lf29xyJKiyRsrxuqvHIjBkkRgGV0ZSVZGUhlZSQwIIOKCZJJ6bbfONk/W+j+Y+iiigkKKKKACiiigAr8mP+C6HxK8WfCz/glF+2br/gm0vrvXtb+GUHw9kOnDdc2Phj4m+KNA8A+PdY2I4umt9F8A+IvE+rXklnHNNa2tnNeSCCzt7q9tf1nr+az/g5R+NHjv4Z/Bz9j7w74A8H3nxFn8QftC+OPGvjv4b2bXIT4kfBb4d/s8fFey+OPgLVxaK91/wjfiX4UeO/Ftn4hltY3vbPTBNf2C/bbS3ZQqOso+q8ttdzsP2r/C/w6+I+u/8ABDH/AIJ4fB+/sfEHwE8WeLvB/wC0RqF3pYH9i+I/2dv2Kfg7oni/wPaaxbxk7/DPxK1fWvCSQI6H7bf2dsxlQxTSDtPiPN4z/aW/4Le+HbHwbYeHfH/g7/gmV+zDJ47k8MeJvEU/hnSbD9o79rKW78NWdrJq2leGvFcY1DT/AIMeG28QeHW1jRriay1ua/jhvtJguI76y/kV+F37YX7VfwB+KEdl8KvH/hpvh9+zz+w/4i+EX7Pf7X/j21mutN+EP7Lfxq+LVr8WvDPxWudHtrbVrbW/jxL4fubL9nbwb8OLBLi40Tx7aT+B5dO1DUfBt/Laf0df8G7/AMWPAPhj9nH9pn4rz/CL42aXp3jH9pnXfCl/8TtQ+Gfj/wCN3xx+LGs+BPCXh/Vtf8a/H3WPh3pXjvxtF421HxP478SXH/COHQbD4f8AgS2mfRtG1XxD4on8a+LvE4W4uMb6PRpW7ydrvzcdLXv8t/3R8Q/thfDXRL+x8G/FTXNc/ZH+IOp6hBZ+GR+0N4d0rSPAXijVJy6afo2h/FCx12/+C3jy71Q7Zx4N8F/GG2+I0UX2ZbzT9BuJxC/xZ+0t4Atvh94x1X4+6H4u1b9gb47an9nudR/an8DaefiT+xT8cFto1g061/a/8F7NM03R4ZNKjitpfiZ8S9I+Hus+B4bvTtF8A/tG+Jvsf9k3f1Nrv7UP7PPxik134eeC/wBob9k/4j3+r2v2HxF+zl8a9c0HSvEerQXSi2fw7rPh7UbxfFnhTTNRaMM6+LPg945uWu/tKLaTW7RWtl+b/wAUPgF4j/Zm+2eIf2eJP2uf+CeCxedLcWnwW8Kt+3x/wTv1syB5LsXP7M2hp4j+JPwx0G5t0htb/wAUeDvhD+z7o2jafK2oTvdG0nmswhb9tvnt+fRWe/zPjX49/GuwjTxJ8CP2o/gx8Kvgp4j/AGgobnUPE3wQ8c+MJNV/4Jef8FEJtR26m/xN/ZM/agFqIv2Sv2ndWu3i8V6DrviKLw/ZXHiS90G4+JcHiDxlqel/ETw/+Lv7TPxp8SeCtG8Y/Crx94k8TeONM0vwdffAXRPHv7QugyaX8X/D/gG/Z9a0j9hz/gpP4UsrxjqieG9SNr41/ZD/AGxfDOoahpGjeLtOs/F/gbxnJ4WvPGdr8HPq340fFrV5fAXxB0m/+Fvwe8V/CrV3v9R+KfiP/gn3qml/ta/sI+K7+GSSW/1v9or/AIJz+NvEGgfGX9kPxZaXKwXXiH40/CXxN8JvHfh/V72bUtPl8V6xZWkVz/Nx+0Z8WIbmGy8LeCfF0PiTwDbaRP4f8Gww+LtY8e23grwlLdm6uPBngDxr4t03wj8YLH4Rz6hHLdaL8IPjV4PtpPCc5fVdKOva5dX/AI41EN4R19Gn8vxs/J3fR2tZfeX/AAXxK6/+0x+yz8XVkM//AA0B/wAE4v2N/jIbsg5vTrXg3WPDQut7cy+YvhMAyEkkoVJyuB+G1fuT/wAFZd3i39kb/gir8XTtkGtfsCn4NC4BLFv+GfviBf8Ahj7MW5/48115E2bvkZ3G1AQK/Dag1h8Edb2Vr+jsFFFFBR/QL/wS/wBX1L4V/wDBL7/grZ8YtF8RaJ4N8U33jf8A4J4fDjwR4v8AE9ql54Z8O6gP2h9Q8U+JdV1+yfS9bOq6TpmjW9nqt/pEOi61NqNrYy6emi6vLfQ2Un2h+zx8ak0TT5vhP8LfC9j8YvGTazcftAfEnRfj74mh8MfD7UviKNRW/vP26f8Agrz8XLrU5NP0nwv4R1q5GrfBL9iex8S36eFrgafffFTWdY+MN/o1t4o/PnwLdXXw6/4N4/i34ntLmXTtU+M3/BVT4eeALSa3le3vX074Zfs+H4j2+oW8sTLLHHZ64GSG5jZXtr6FSrJI8TN4p+xt8U/FGsweGfh/4Qg8K6MNO1p/E+j2eofDrVPj5NYeLdOguD/wnfgf9lDwva6pafG3426Xatqd3ovxY/ahv9S+GHhG1nk0Dw7N8Lk0jRr9gxavzvtK2vkoJN9X3t+Pf+vf4NfEjwD8DLHUv2ufiv8AtDWo8e/FvThovjD/AIKcftQeFXtPiD8UdKlnium+Dv8AwS5/Y1vtNn8Tx/CqGW/RvD3iq48GQ+GNe1N7LxRb/Dv45aHJb2vh/wDRr4ZeNPj/AOPvDV/4g+GXg69/YT/Z/wBYubC88WftVftkTad4h/a/+MDSSG0t9b0b4TeL7240H4Y+fJI9p4T1z9oTWtTPhzTLvT9E8P8A7NWm+HI9NsbP+e79n743fAH4QfFC18c6x8VNN1j9rbxUBZf8Lc8eG9/4Kl/8FQvF0gSSWPw/8KPhJ8FP+Ez/AGWP2M54IrmWx0fw7rvjj4sa3oFjJN4a8WaTdtHbRQft98Kdb/ar8UPD8TPAf7H978LDYxSXqftd/wDBWv42WuqfFnSrG6gW21PUfC37NnwnfW7b4Vwagk5OoeDNC8afs0eGZlic3GjRXFwzUGLX/Abta2m3dK1tNLackT9Vfgb8JPhj4ItL3xR4TXxV4s8W69Etl4j+LvxRl8Ra98UPGsCNDeAXXijxdaWuoL4Ra5YX2heGfCVro3wy0ZpZV8F+HNI08Lbr+XP7Osmnfsv/APBZ79tH9mxrm10/wJ+3J8Fvh7+3J8NtCllgg02H4p+FNQv/AIRfHvS9Kt3cG98S+N2stN+I2vW4Sa4k03TJ70BbS0uPL+zPhp8NNQ+KrW+ofFL9s7xt+0LK6C4n0T9n6eD4F/AjTL2IK5jtbz4LapqnxLZbgAk+GviV+0T44sdQsyIzpM0Ulw0/4cf8HGvhb4X/ALPfhv8AYi+Kfhb4fXHw1k0j4qfEXw7pnxn/AGfNCtvDPx6+DfjO48LaD4v8JfEjwXqWjT6KPF1rocPgjxPN418AeJ9Qh0/xx4eudREXiHwj4ms9F8aaIExV3a/xK3ps159LafJnZ/A3wv8ADvwT/wAE8P8Agtx/wTq+MmqWfhz4afsb+Of2obLwfcajmaPwX8APjb4H1P8AaB+AeqwWb7pptV0fXtV1bVtHs7dJP7Q1Sz0+306CWeVYD+y3/BLL4l+Lvi//AME5/wBi34hePbO+s/GGu/s6fDCPXm1Mqb/VrrR/DNjokPiq4w74HjWx0608Y24Owm116BxFEHEa/wADXxc/a3/aI+OHxZ+PNh+0RqPhK3+Dnx7+Bv7NPxd/bO+MnwmvbvTfC37VnwS/ZI1rWdC+HPiv4XzyaZpP/CNa38evFet/D34K3GmS6LDeeCfjV9o8N+KvD3gaLSfF/gfwv/XD/wAG53xd+KfxW/Y3+OEXxr0a48K/EvwN+2b8Z9A13wXPYyaRH4Kh8R+HPhx8TLPwlpugyszeG9E8NN47uvD+i+GgIh4f07SodHFvbiyEKBc42jfTdP74pP582+mit3P39ooooMgooooAKKKKACvxa/bztoNU/wCCr/8AwQ90XULWG90m+8T/APBRK5vba4i8yCebT/2Ri9pFMD8kkLmecy20gaK5RTHKkkQdG/aWvxC/4LFx/En4MeKv2GP+Chngv4Y658XfBX7BXxf+JXjD47eEfB91Evjaw+Cvxd+Glz8OfG3jjw9pV1E1trUfgixf+2dUtPNgkgtxFd3Vzpfh+HX/ABDogNb+qa+9M/JX9kf/AII8fsn+Gf8AgtP+2/pnie6nuP2dP2Rz+z/8cvhf8DPFU0MXw3Txp8ddH8WeL/C8Wux314NO1rwb8FtXi8aQeCtEvrRvtD65psGs3l7b6dr1p4p/ST/gjH+0L8A/A/7On7QqfED44/B7wR4k8Sft/ftpeJbiz8YfEvwd4bv9QGo/Fu9WDVYtO1nXbCdrK6tYbYwS20a2s8YWSNiX8xvnex/4KIfswfAv/goJ+2r+29aeP9K8Y/AL4v8A/BK/9nj9qDwfq+g3cQuvHE3w8+LXiz4IaV4H0yK7RZ9L8bal4313SPAl54f1WG0vfDvie/az8SWmnyWN59m/R7/gjv8AAT4r/C79iy71z9oPw/oujfEb9qL4y/Fz9rnxB8LVsZxpvwvX4/65D4v0r4cXjat9sv57zSLI2t7qq6lAdQ0bUtVvNBuRdT6K13dhcm2vev8AZSu97Jc3Tzu79WvQ9L+N3i79n740aB/ZHjnxx/wTm/aM8KSxM0HgX4033gwaHLDcR7jNH4i1PxD8YLBPtCCNd8PgJ/lAmWV8Ii/kH8Qv2bPgf4KEuofAjwrafs3amVnkS9/4Jtf8FmoPADJGGYwWqfDL486D8IvgpEjHG7TovDiaa8ZFvPPPBFEqfrr+0j4Y/Z78LwzXnxd8M/8ABNv4caa6vLLqv7SGneCdQi+yFywvZovE9h4AgkVfMnmeF9SETtI0RvU+e4b8D/j947/4JXX17qWk+GvFv/BFbxprjm4gW0+CX/BJf4w/tGeJLqUxJGiWuv8A7O3x5sdLnu0jT/RLzUNTh07IjxIkKkMCj5Xt10bX2e2nfe+m6eh+a/7YmhfHvX5pNc17XPjD8e9W8P5Onal+0f8Asm/svfFjx/4Va1R/IuIP22P+CdHx38eftByWyxJGzz2llotpataLd/ZngHnL/Mb8V9U1vV/HviC98SJcprz3brqpu7jxfdzyXalizvc/EDf46lUoyLGfFl3f6wkSpFLdmCO3gg/fb9qj4MfCS/0LVvEvgb9mT4k2Xh5Xmb/hYWi/8EfPHH7NXwdtvMVpo/8Ai4XxL/4KF3a6UA2ZY01Hw9Gi24c/vLeLyF/nl8VwafbeIdUt9Kt4bbT4bkx20MGo2erQqiqoLRX1hqes2kySMGkUQavqaRBvKF9c7PMYOmmla+nba3RX08337d2z9pv2twPG3/BDb/gkr4vCmab4O/Gv9uP4M3l31Zf+E4+IGkfE7T7OZwfnEVjYr9kWTJhhSRYgqO5f8OK/cu0z45/4Nz9WgLCXUvgZ/wAFY7HUR0ZrTwd8RP2Zzp6w7R80YufF00s3mE7HMXlgF8lfxB03TdR1nUbDR9HsL3VdW1W9tdN0vS9NtZ77UdS1G+njtbKwsLK1jluby9vLmWK3tbW3iknuJ5I4YY3kdVIOH2l2lL5Xd7fiUqK/o1/aY/4Nxf2qP2dP+Ceng79sC5urjxP8WtHstR8a/tE/s/6VpyXWqfCj4Z31paXej6npl9aPNN4i1/wLbRXl78XrOCNrTRrbUJJ9HkutK8Ga1rer/wA5VBSkpaxd+h+4/wC0iP8AhCf+CC3/AATZ8MlGgPxv/ax/a9+MqqRtF8Phrd2PwhN4O8nkG6+x+Zg7ChTI4Ffl/wDs7eXf+J5tB1LwR4r+JXh++eym1XwV4e8O/EHxxBqIhuENvcXXgb4e/Ej4Q6jrVxBOIltZrr4haRb2waRUtb24lha2/UP/AIKjk+Ev2Bf+CIXwh37P7F/ZK+LXxl+yY2+V/wANBfFmDxP9r8vPH24aAG8zjzfJ3e5/Jb4H2Gmal44s7bVPEGl+G4SpZdQ1nwt8HvFunqeUYT6Z8cPHHw/8COAjllF/r8bs+1kjzGJIwmPwtvrKTta/2nbp2S/M/rV/ZA8TftCeCfC0WifCn9mv9pvQvDUtpEuo+HfCPxQ/YS/4JB+D9TtYFje4u/Gmv6ZpHjP9p/XLmGOGOQ6nrfxy1zxFGqMFlncQiH9ZPhM3xXXUNN8Vr8JP+CQPwg1zTnFza+OP2m/24viT+3Z8edInKsXuY/H3ijSbPWp5VUn7XLH8W7Jp3VCd6BZI/wAVP2T/AID/ABJ1HSbPxH4E13TdT8NWf2Vv+Ez0D/g34/YV/ab0c5G75PHH7GHxH+N/ibVIWAuFheS9fUZoXkkt4I2dQn7gfBHWPjX4I+wDTP29/wBg/wCHcsIgW3t/jh/wSP8Aih+ybdhkjeKBDZ+M/jh8A7q1nBfEdvFDbSpKFhjiVWaJwwla7231+O2ijvo136fofpd8Nb79on4omF9Y/wCChP7MGsLemArp37KvwN8O2N1bC45jgsde+KX7QH7RdvqVxIFPkahL4TtILlw0i6Qkf7hfiX/grF8N9Z8Oap/wSfn8S/Fr4k/FOa7/AOCv/wCyX4XLeNrf4Z6QIdK8R+FfjLBrQij+Fnw3+G8bXF5a2sdsZrhLg28BmW1WAzTM/wB5fDnXf21fGViuoaH+05/wT/8Ai5ZRSbL66+HXwO+LGlWUeTGQEvLL9r74oRRuw8xfLlxtLo+5gjRy/D3/AAVy8Afthp8B/gt+1FpWhfCT4nap/wAE/v2jvAH7Z+ufC/wbb+NNGvviT4V+GGmeI9M8Y6bpcmp3Ory6dqGh+F/Eur+KIJheXp+y6PfKum61eGz024DOPxLbt23Vu39avzf5ja9/wRi/Ze8Of8F9vhB4J0i31Rf2edd+BPjL9tIfs+iJp/Afh/xp4M+J2kaC3geytHuZbe1+FGsePtS0Xx/L4UazOmpd2M/g1YP+EcubK3sP1+/4JYZt/wBpn/gshp0KeXYxf8FDNR1KNfnbN9q/wf8Ah5PqT+Y7MT5kkMMnlA7Yd+1FSMoo+Hpv+Chn7K8n/BTHX/8Agofr3xH06x/Zm+GH/BGLwBfQ66DFNq934x+On7St14y0bwJpOkiSC51H4i3uneFF8L2/g8mO+t/EEOrWt7HZiwvbqy+6v+CLng/4t3vwn/af/ao+Mfw01H4Pav8At2ftc/EL9qbwF8Ntevxe+KfC/wAHPFvhXwNonw5t/F0aWtilh4gvrXQdS1RrQ2sU7aRe6Pe3cdtc3kmn2IVJtrW+kVFeujt623/HdH7LUUUUGYUUUUAFFFFABUU8ENzDLb3EUc8E8bwzQzIssM0MqlJYpYnBSSKRCUkRwVZSVYEEipaKAP42v2zf+CMn7JX7Pv8AwVZ/4J5/FfRrDWfC/wCyt+1H+0Xrng34jfBWwmaz8AeFPjbpnhm6+I3wn8PeE/s9xbvpvgT4v/EHw7ZprHgMKLXR5dCv4fDdxHo+paZofhj+q7xH+zZ8JPGTOvjPSvFXjSwlGJdB8ZfFH4qeLPCkvLczeEPEPjTUvC0rENtLyaQzsn7ssUwo+Mv+CxfwC8XfHj9g/wCJ138LUlHxy/Z81bwl+1Z8Bbu2ga61C0+Kn7PmsR+PNNh0m3TbLNrGveHrLxL4U0qOKWF2vvEEH7wKGVvav2fPirr/AO27+zp8G/2hfAPxVPw2+H3xm+Hnh3xxYWXw30Hw9q/jfQr/AFKxRNb8K6j40+IGn+LPDMs/h/Wk1TQdetbL4Y6bqWn6xpk9pY+ICLNry8C221FtvS8fkrNX08/N6Hnvjr9nb9mj4C6LrPjXSPgF/wAE8P2Z/CunST32pfGb4ifDvwDYWOlBQ7i88QaRaeHvhVp0t3dRxtNcXl18YrWSF0kZpL47pF/Ofxz+1XrvxgtJfDP7MPjH9vf9s9m82ztdI/YN+EvgH9jr9kCK9yfLtrr9rP4peFptd0rT2h2+Vq3w5/aA8ZWy2832hop5IPPtP1Y1P9jb4MaX4gsfGNn8GPDHxo+KdoZLvTvi3+1D4v8AEfxj1TwbO7YuLrwrqnxGm+Iev+GpUnMeoR+EPh/aeAPClxbRTWVtq3hwfZYq/PP44fFG0/aG1nXvhZ8IfDvj/wD4KceOtOurnRfEfhfw54ib4Bf8Ey/hPqVrI1lqNj8YvHOiXt5o3xbXTCpm1z4La34u/af8Ri/sr2zl8OeCZzby2gJfl1fy/Lp7y/Gz/m6/aO+GPjr4ka3401BvDf7NuheJfB8N1L45tPhjceLP+CpPxu+GqoUmvj+0j+3P+2l42b9kf9n2S2v2tYtR8SaN8TfCvijw7dH7XZ+E7jZBYT/zSfHTRILXxTdavpviDUfGWm3N9dabP4ofXtT8d6UdXsEha90SL4j3PhTwVo/irU9LE6i6fwroUnhiKxk0250PXtfsbxL0f2T/ALSXwft/GXw71D4j/tLfHD4W/Fz4P/Bq5MK6vp2ha38Bf+CNn7LesWxvI4/BnwB+CfgG+0/4nf8ABQr44aZqMV7pvhXSdC1GDwjfakZ/CvxH8SxSWV/4Nf4s/wCCbP7MOlftZf8ABZP4QeHPiP8AAvxbb/Cb4JfBPxX8fdc0X9ojw34bsfFPxJ+H2s6Qnhz4YXHin4G6Fa2nwh+CHw91Pxb448N+Kvhr8A/CHgrT9I0HwFdBrjUvHVpq0HjG8DeErXb1sn0tpZW31d2tnte+q1f5/fsd3Nv4t/4Ij/8ABYTwZcyRLP8ADD4l/sGfF7R4p5FTzZ/Ffxd1T4catJbbyFE0OnwwxychpvtUFvEJJZFSv2R/4Ilf8E1vhH+wt8BtQ/4LHf8ABSD7F4M0zwh4Zj8cfs/eCPFVmslz4S0W+jRNA+KN5oFxtuNX+J3ju4urLTPgt4Ujj+2aeupWXiKOKfxFrnh+Xwp+gX/BTP8A4N9P2VtP+An7Tvxz/ZH8deNv2NtdtfhB428ZfEX4aeDvE90v7Onxf0nwFpV38QLfwh408E6vrOn2vhnTrvXPD+nS6TdabrUfgzwfqUdv4gg8DXl7Y27R/K//AATW+EX7QX/Bbfwr+yR4p/a50K88Lf8ABOT9hP4d/DPwH4L+F09zdPbftjftB/C7wlp3g7WviD4xEkNtFrPgzQpdOnsdYLJPpUTSaj4G0Zrm91/4lXemAnNOMmtIyleXR/DFcq7uVnr230uemfDf/grR/wAFDfhf8SvC3/BRL9sv4N6h4V/4JMfth+I7f4YeC/B1tajV/Fn7MHg2yuJLb4U/Gzxbo1tpw1N9I+K39r6xN4j1K5ku18c2Fv8AbNCsdPsbD4RaD4u/IH/gvx/wR10T9mbVIP28P2O7DTvEP7F/xqudK8Qa7p3guS31Tw58G/EXjcW17oep6Bc6Y01k/wAGPiNJqNtc+CtSs5JNI8O6xfxeFEltdM1TwVBef6GnxM+EHw0+Mfwv8W/Bb4l+DdD8XfC3xz4Yu/B3ifwVqdmn9i6h4dvLYWjaekFv5DWBtY0hl0u7097W80i9trO/0y4tb2ztZ4f4RP8Ago78NP2wP2CPhRJ/wRr8QeIbzxz+wx+1l8ffhK/7I37Rfi/UY47n4UeDh8UdJ1/xX8DvHl/cGz0hz4T8US+GPFKrc32i6cllYXvijSzb6Z4ivdA8DhMJe8mkotaNdHC6/wDJo733a16O/wCZv/BdO5g0n4o/sD/CizkhNn8Ef+CV/wCxf8PGS2kjlgfUB4d8TeJLu+3xFkkmvrfX7CSWdXf7SscVwXZpCx+If2SfAviC81LTtZsNJ0fxHa+IdUGi2fhTWfF/gjwH/wAJnq1qZJl8N6JrPxy8H+Pf2aPGWreWIrr/AIVf8QNKl8eeI7h7K38H6HJJdWV/df6LP7M//BAH/gn/APAbStX1L4geEvEH7Vnxk8U+HLzw/wCJ/jd+0jqi/EDxRt1HR5NFup/CGg6jFL4T8HzWVrNJH4e1WDStS8X6LBHaQHxbfNarM38X/wCyZ+zDrPgHxF+0z8Nr7xBpvww8b/swfFr4g/Bz4v8Aj+y0E/Gn4fS+FvC/iufT7fUv25P2SfEFj4gTxv8Assa34ijvNGsfj38NtI13/hR+pWKap8TfBeoWN94A8WaYFxmnFxW6tq+uurstbX7a6o++P2c/hN+yxrfxIsfA/i74ZfDD4X/tP2Agih8C+PNY+O//AARn/bVtbi6fyseALvwX4o+IH7Gfxgv7m/jY+HbHRtK+Dl7r0dut8+leHIJodPi/oO+HHgb48fB/ydP0n9vn9vT9m5oTEbjwj/wUi+EPwh/ax+FVs52rbQyftL+Bf7I0RrOf54LDTp/2rLXxJf71NzarchI4fzy+E0Oj6dZeB/2V/wBpvwF8Jvhlb+OYLZvhF+z/APtV38n7S/8AwS0/aYttUtbWXStW/YG/bD1aLxl8R/2X/EfiK0eDVtE+HGp678RNN8N2+p6PaeFPhfe6xdRf2f8Aqf8AB39njxj8CNR07wl+zD8bvjT+xxrodbfTf2QP2snuf2p/2TfEDwrJKmk/Azx9qXi208baVaXixX15Z6H8Mfj7Ya14d0uWDWvGPwG0ZkXRpQyk9b37WurrZaLdfcn662PsPwnqX7aFn/YviLxn8PP2P/2irKK1ju9N+JHwj8ZeN/hF4muLC4QOtx4U8BeO/DPxk8OXIv0kEsZl/aG0ex2Ef6VcLKJI/pjQfiHceIY/7O8X/Cn4k+A59QRrdNL8U6L4c8V2l/bzBobgXOq/CzxJ8SPDVhbsCY3h17V9LnmifeLZod7L4P4E+KPi74dXV7b/AB5/ZrT4Tavqc7S6x8U/gaD8X/gx4lvHfzpdT1jVfD3hjw18WvCcoX7Rqes6t8T/AIT6N4M8OxNPC3xJ1cmW7loft0fth+Ev2Vv2Ivjp+1Xo+taL4jTwf8PNTn+Gk2k3tprel+LviX4hlTwn8MdCsJ9PluodTi1n4gatoWnXX2L7W0No95cNC6WsqgIs21pvord/6e3TyP5wP+CT3/BGv9k34l/tnftr/tP6xp+peN/2ff2dP22fir8Hv2X/AINa8kNx8NTr3w11b+19T8W6nYO81v4y8NfD7X/F174a+GlhPEdFkkstV1fWf7bvn8u3/sdr4E/4Je/swal+x/8AsJfs8fBHxP58nxE0/wAGf8Jp8Xbu8cz6jefF/wCJ2pX3xD+JX9o3zlp9Sn03xZ4l1LQ7e/uT50+naTYqViSNIYvvugcpOT1bdtFd9Fp+O78wooooJCiiigAooooAKKKKAGsoYYPTuOxHcEd6/Aj9i7W9X/4J2/tpfHv/AIJl3egTX3wq+Nmr+Lf2t/8Agngh1DTtC8PweG/F19c6l8dvgDDqF/IkGmWvwk8YG78W6Zo+j23iPxOvgbUtY8Uvo2oSXljYzfvzX50f8FLP2MNc/a7+C+gar8IvEMPw8/a0/Z18X2fxu/ZM+KnyQt4X+K/htUnTwzrd0Y5GfwH8SbK3HhTxnptwl1pcsM2maxqWlawugwadODVtU+ul+zvo/wBH5NnsPi39nC/+OCyj9pbxVeeOPBkiyyD9nnwTc3/hf4LX1u6749M+Im25tPFPxxIDTWOoad461XS/hJ4hh+yXd58GtM1C1W7Hzp+03rngD4d+HvB/wq8YeC7v4kXvimxm0X4Bf8E6P2fLbTNLs/ifa6KkFo//AAs14U0LSH+DvhuO4s28d33i9vB37OPg3SNUfRPGuk/EvWW8INqDv2Mf29PEX7cPwSZfAvgyz+GP7T/w/wBTuPhl+1N8PPiDZ6h/Z37M3xc0OW50nxFZ6r4eXUNP17x1banqGn6lrXw90XSdX02317RIfs/ifxn4Q1C3lSX6u8Hfs76L8NNP8U6l4T1/Urn4sfEiWy/4Wj+0F4yXTPEXxX8R21lHcsk8V5PpsXh3TrXQ0muYPAXgfTtF0v4UfD6TULi+0fwLNZpf6DrgGz10t+enb8WtX+J+IHxC+A/jfX/iTZfEz9pnxt8FfFn7Svwo8Ny+KtG03W4Ym/4J3f8ABI34VWWkJq6+KtJ8Fa3JoNn8eP2lrXwtb2+r+GbvxbBpV1cvBo3i3UNK+Fnwu0Pwpc+IvO/+DcD4Z6D418Y/8FIf26dI8SeOPiFoHxx/aXvfhP8ACn4l/FO/u9V+I/jj4d/C77Zr114/8R315Zaa/wDafxGn8beHL/XrK303TtJ0nWfDk2g6NpOkado8Onw/HH/BX34b/Cf9o742f8Ew/GWpfCKzX/gnhY/tkwfspP8AEmTxP4n0/wAaftEar+0DruiXnxJ+K1n4jgvU17UvhxZ3fgDU73wt8WNW1+88U/GLxFF468c2FxqPgq/8L+KvGPtFr8VPEP8AwbdfGr4t/BPxVb+KfGv/AATY/aH8NfEz4t/sh+Jb7+0vEl78Ff2g/DvhK+1y8+Amv38azag+neOr6w0zR9Ouboyi9e78M+KxcJdp8WdTsw13ja75pbR0srNaLz2dtLJNb7+J/Hf9lj9sX/gtT+1X/wAFcoP2fv2t9Y+DfwQ+EXj34W/ssaF8KvEN74ru/gf8btb+FFpNN430rxI2gX91beH7nw58RPCFp4qs/Fmn+DvFV9NaeLodLFuNLlnluPq/4ff8Ffvi1/wSe+DPgj9mr/gpP/wT58dfBaP4W/Dq1+H/AMEfix+ziugeLP2f/jXqXgjwxJFoWhWV3Hd2mleBvEniqPSku722t9a8Q6lb3mp3Gsa94T8KWSTxRfU3/BFtPBH7C/8AwRt8PftP/tJ+LbTwba/FN/iH+2X8b/HGvBla5b4n61HH4S1MLDG15rGs+KfAmlfD2HRtJsoJ9T1zxDrFroujWt5eXtlDP4n+xd8FfiZ/wWG/aa8Of8FS/wBsjwhqfhb9k/4V6leJ/wAE6P2V/FEYe3vbS31CNk/aK+JOkMZbC+1HVrzTrLVtDTbcw67q9lpVzZXM3gfwb4XuvGIJtap2cI27ptpJaNWu3br0+R8kaF8X/wDgsH+xprmj/wDBZ/8AaktdV8cfs+/tFanY6X+1D+xT4fj1U69+y7+zebuNPgh4z8OaNqFyLHTNe8HprWsX+s2JttO1SxbXDD8Sbw65488X6t8O+4/a/wD2i/2nf+C/3wQ139mP9hL9iK/0f9lnxT4s8Palc/tzftZvb+A/Dtpe+A/Ftvczat8GvD9tZ67qs91Ld6VqXhTU9f8AC0vjTxJH4c1rxH4c1bwp4Uu7u9mtv2k8AftieKPjT/wU0/bK/wCCdXjb4e/DzUfgx8Iv2d/hz43h1O70/UtS17xovxT0bwrD4m8MeMbDVNRvPC+o+G5bTxVqNibGLQ4DdWYS3v3uo3nEv5U6Zc+Kf+Dej9qaLw/qtx4g8Rf8EdP2s/iDIfD2q3L6jrlz+w58avEbNLNpd5O/2q8m+GOuiJ5Q8jPeXmgWMmpx/wBoeMPB+tt8RQL3d+Vc6ScUtE1ZNabuSTutXfZ3sk63/BP3wj+1B/wTr/4K6+HP2Of2pv2qvGv7UmkftX/sPaXrvw58XeJJNbsPDmiePvglr+vTp8N/BHhvV9f1u00jSPB3gTRPHd2TpsemHVoNa0vWLrTLO8u722j+Pf21v2ePBnwa/wCC/wB4t1WH41a9+yX8R/2sfg74I+NX7Jf7ROkQzXvgXwh+0dptxb/DzxH8OvjFoE8qaF4i+E3xmHg/xVbfEOw1kOI9W8XeERLNHo2q6lZXv6b/APBevUbX4NRf8E4P+CnnhCVdasv2Qf2rvCM3i/V/DTx6hHrP7PfxytbC18bzWmoafI8Gp2GsW3hnR/D+jSxTT28n/CbyTWjSRXcy3H4u/tl/DjxJ/wAFFf2Pv23f+C1n7Zuh+JvCfwq0HwFZ/DH/AIJofAe51bUNBk8L+Fdb+J2geCNA+Mviu20m7hOral4m8TeIUvIrO5nvNM8S3Umu6lNb3ngfTPh5KQcNbS25lyOyVua6SSW2uja0Vr38/wBwP2c9J0vx7afEv9l3x/8AAb4aeE/iTbWN54g/aW/4JmeOG0vxB+zN8ZvDV7qbR3H7UX/BPvxL4jim0Xwt4b8V6tM2p3HhmzKeBdI8fu/hXx9pfwf+IeoXnxm1T7R+Gvww+KfwO8Ny2XwA1PxD+07+y9BJLpPiD9kb9oLWBJ8evgolqsMreEfhL8TPiTdK3ibStJt3tTpHwg/aL1Ywy6XLpmqeDfj3o3hAaFomqfOv7Ef7I3hvxF+wD+wt8MvE/il7648I/A34YfEf9ln9rL4RnQtO+IvwV+JninwBpuv+M/D9jrmm2F5oN9pdzrep67baY+q6bqfgX4teAWm+GPxm8Pax4h0m21z4nfpx8HPH/jKHXj8Mfj9oWg6N8ctP0hLex8e+GdNew8BfHfwro7zTL4r+H815cX+paFqFmbqW88Z/CHWtTvdb+H2rX15Lpmo+MPBV7ofj3xAGba2T6t2fy1Wv5arZt7nqfwt+I3gb4ieHzP4KvbxRoUkOka34Y1/TtX8PeNPBeopbxyx6D4x8I+JLez8T+GNUW0eG6tbTW7G3a/0uez1bTHvdHvrC+uPxZ+PunaR/wUE/4Ki/DH9ljwppWlXn7O37AGt+E/2qf2yPENhY2ZsPiB+0rLYXUP7M/wAEdXv7eH/icXXg+zk1H4i+K9N1BtS0q601Z/DuppYaxpNvE31J/wAFN/2q9N/Zg8IeBtO+EXhGD4h/t6/H7Vz8H/2Pfh9o7pD4m8R+K7+RZr7XfF0ttLDNL8Efhut2njL4g2/iCX/hDWlttLh1OXSbq8tte0r2P/gnh+xhpv7D/wCztp3w41HxDJ8QvjJ438Q638W/2kvjDfeZLrPxf+PXjyZNT8e+M7+8uI47yexF75ei+HI7pUuIPD2l6a16r6nNqFzcALRX73UfXS7+Sennqtj7qooooJCiiigAooooAKKKKACiiigAooooA/Gj9uj9j742fDv41Wf/AAUo/wCCe9hZP+1J4W0Oy0D9oP4BXFyuk+Dv23PgvooieTwdrUiRtb6Z8aPC+n2qL8LvHTwyXYNtZeHdQa70+3sLE+x/s+/tR/Cf/gqb8MWb4fXmseHfhno83/CM/tOfCfxR5nhr4waJ4/gJTWv2dPiJ4W3xaz4a0G2lt7yD4g6kywaf490lR4S8P3up6Jf+NVsf00r8mv2vv+Cbms+MviuP2zv2G/iZb/sqft2aXp8VjqfjCPT5Lz4N/tHeH7IQtD8PP2mfAdlFJD4o0y6S1t7Gw8dWFnL4v8NIlnfRx61PoHhmPRQpNPR6NbS1+526drK69D5V/wCDk74d6c3/AAS28UfEXRb638Pa1+zb8UPgV8R/htpkN1a6TpFrrdr8RfD3gO2Ol6SGt7O51PSfD3izU20q3iUy2elQapa6ZDGl3cxT97/wWf8AhF8Qv2/v+CPfi6b9n7wjofjjxP4r8KfB/wDaI8M+HbuxTV/Ed74Z0g6J8Q9Ui+Gk4t55YvHlz4VnvLHS/sPl3viLRrzW/CNm0s3iVLeb5z+Kv7VPhH9svwt8UP8Agn//AMFMfCUH/BPz9q/xr8FPiJ8OfhBp3xLnOq/s4+PfiX418N6t4Sg+O/wV+Ls9xD4T8YHTGvtL07w14Ou9a0rxfodl4i8aeDbbWPFWsa9dvovD/An/AIKNftL/APBIHwj8IP2R/wDgq5+ztfad8B/h54Y8LfCL4Nft2fs7Raz8R/hTq3hDwZpen+GvCsHxM0AQt4m0fUrPQrK0hlu4bHTvF+px2sbWnwvvIludblCkmlG1uaMrpb3Wj0tuk1sm3qfRnjnxv8B/+CmX/Bv78YYP2cLHyPCtl+yXqfh/SvhlcXFrd6/8NfiV+zd4X0fxfovwq11YobdU1bRNf8CeHYNJvms7GDWtFvNC8T2Fvb6Zq1m1ev8A7LH/AAUG8CfCD/gh5+z1+3V8R9K8T+MPCfwv/Zm+Fmk+ONM8CW+i3fijWNd8EatonwG8RvpNrrWr6Bopuj4z0u7uruC71ewiggjuo4mMsMdu/wCYnxJ8dfDP/gm3+0pH/wAFNP2S/Evhn42f8Ekv29fEFj4K/bc8IfC3ULfxd4R+DPxQ8S3D2ln8Z9G0nRGuJNEt9Qu9avD4l8NT2kV3aatqnifwLfWWn6j4p+G+n6D8XfBzxrpsP/Bt7/wVT/ZtsfEtl4ntf2Tv2jfGvwx8Lapp2o22q6bqvw51r44/Cvxf4X8S6Vf2jvbXmk+JNd1Txpf6fe2rPaX8K/brWWSK5G0Gop8q15edeqvZST7NNLvo0/X7L0z9u34Yfs2/8FUv+Cnf7enjHwt491r4W6Z/wT7/AGH/AIjT+FfDNn4euPH76P8AFb/hnzR9Cs4rPVPEWleHTqVhc+N9Mk1aN/EaW0UFrftZ3V5IlvHcfXX/AAcGfFRvin/wTL+Dfwr8Dx3dnrH/AAUB+P8A+yx8KPB2l30dudZgs/Ger2fxYsXu7a1uLmMSWd74S0DTNS+xXU0IutShtFuZYbrMn8+P7X3/AB4f8FVf+0Sf/BKL/wBSX9iuv1B/4KIftCfCzwX+09/wQv0L4y+JIfDfwg/Za/Z91X9u34tXchS4m2eBPhj4bPwbh0/TS6Nf+I9b+Ivw2uvBng7TomE2s+J/FmnabE0bsZKB21hK13p3fw04Nbebt56H6A/8F5/iL8GfhT/wThl/YltfCuofED4r/tS23gP9nj9lX4H+GDFc+LNe8WeGPEHg2fwz4htLNIZpv7F+H+o6V4YuZp47RV1DXrrw74bjmsZNdF/Y/J//AAVw8CfE/wAO/wDBKv8A4Jf/APBPz4m32lXnxn+PHx5/Yi/ZY+IcHhOWWbSr5/C/hqOw8RT6bLELf7dHZ+LNI8IRPcW8Fta3V1Ob6zgsoPs8EXzd8Df2v/gV4K+Meuf8Fp/+Cp3itLD45fFvQZdB/wCCcX7EXhmAeOvi78M/2er59QtPDPivQvAUc1tNpfiD4n2mo6inh/xr4qbwj4Z1W21zxR4ptdVZvH2jaVoH1donhb/goL/wUy/ao/ZJ/bl/aP8A2b/D/wCxv+xX+xb8RtQ+Lvww+FHxD1vU7n9or4hnXBodu/xF8Z6K9pb2fhzT/ByaDp3jNdM1zRvCOqaZpVlrGnaLb+OX1ax16AEtEu0W5XfWVl7se9mlfdNpu9j9x/CPgKH9lT4gajaeD7NLP9mn4veKZ9VfwtYwrDpvwH+M3ie/ebUtS0GziCwaf8JvjNrdybrWNLs1ih8D/GHUZ9dgtbzQvihr114D4D/goh+2Z8CP2SPhbor/ABJ0LV/in8WfiDr9lon7OP7PHw+WW++NHxf+LMdzDH4btPhzZabDda1oUukandWU+p+Pre28jwrFcQrB/aOualougaz8sfHr/gqcnxf8W+Kf2Uf+CZPwq0r9ub4+vDdeHfHfjl5yn7GnwHtdRjmsb7UfjX8W4gdF8WPBA8zj4deBLvU9R8SxW+qaPFqttrdsui3nsn7EX/BNTTP2f/G2oftQftKfEvV/2sP27PGWiQ6N4o+P3jeKSTSvh54fMDx/8K0+AHhe9aeD4d+A7CG4uLOa9twniXxQ1zqV/q1zZWus3Gg24Ra2stOy2b2+5W1vu/nc5T/gn1+xF8XNB8f+J/29v29NX0zx5+3j8YvD1t4ftNI097e98C/sofB8k3elfAj4Ux2+7T49RQzPcfEfxdpjMuv65NfWtheX8Nxr/iTxp+u9FFAm7/1t5IKKKKBBRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAHjPx4/Z2+Bv7T/wAPtS+Ff7Qfws8F/Fz4f6r+8uPDfjXRLXVra2uwjRw6rpFzIq6hoGuWiu5sNe0K707WtOdjLY39vLh6/HXXP+CVn7U/7M9rcwf8E8/2sNN8S/CMaFrvhlP2If8AgoJoup/tAfs9f8In4hk06XVfAvg/4iRNL8Vfh74KuU0fT4G8LpH4ntdQlUXGqahKqPHL++FFA02vTs9V9x/n8/tcfsWftHfA+0+J/iD4b/sE/tQfsM+JfiToN/4a+LPhT9lq7sP23v8AgnP8efDWoCS21Wbx58MfDo/4WF8D9EdLq5vdGFx4P8dL4Ov7XTbjwj4T8Kat9k8TWH43fsnftR+HP2dv2Lv+CqX7IvxXvda8LeI/2lPh18EE+Gug6h4a8Th734j/AAp+L1vqOo6TcQNo5k8MPqHgzXda1KW+8SJo9tOPDtpp8s39ovY2kn+svXAeNfhR8L/iTE0HxE+HHgLx7A0S25h8aeDvDvimE26NIyQNHrunX6NCjTSssRXYrSyMFy7EhpGpZWavqnvr7rut7+lvxR/mi/tGft0fsyeP7T9vuLwr4/u9Rk+OP/BPX/gn/wDAX4Zh/B3jSx/t/wCKHwL1v9mS8+Jvh+Y32gWw0aHw/b/Djxe8Ws60bDRNZOmImi6hqD3+ni68/wD20Pir8Iv+CmP7cPgi40j47HwN8Gvhl+zR+zb8GPDnij/hUfxm+IvjfxFH4I+HekX/AI40LwD8JfB3g281zWdb0/4oeIPHNpZweKb7wJ4R1CKyj1Q+LYI9T077b/pyXHwK+CV34ebwlc/B74WXHhV9LTQ38M3Hw+8JTeHn0WO3W0TSG0WTSG01tLS0VbVLA232RLZVgWIRKEro/B/w68AfDyxOmfD/AMD+D/A2mkIraf4O8M6J4ZsmWP7itaaLY2NuVQcIvl4XsKAVRK1k00rXunbSCuvd7R/F+h/IN+xR+z34j+EmueHvHn7An/BKT9pT4wfH99TfV/Ef7e3/AAVZ8SaJ8DZru9vNA1LRzrfh34e6rd+JfHj+FHvtVi1OxHgHTNL8cXlnZWEWt+Itcitkul/WNv8Agl5+0x+17LHqX/BU/wDbN174p+CZ5Ybq5/Y4/ZOt9c+Af7LrBJBLJovjbxDb3qfF/wCMmiiXMlofE2q+G7+ylSIxXDonl1+5FFBDk279e+7+/pbpa1uh5l8IPgv8JvgB4D0b4X/BP4c+DvhZ8PfD8fl6T4Q8DaBp3h3RLV2VFnu2s9OghW61K9May6jqt6bjU9Tud11qF3c3LvK3ptFFBIUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFABRRRQAUUUUAFFFFAH//Z');
/*!40000 ALTER TABLE `images` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `industries`
--

DROP TABLE IF EXISTS `industries`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `industries` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=78 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `industries`
--

LOCK TABLES `industries` WRITE;
/*!40000 ALTER TABLE `industries` DISABLE KEYS */;
INSERT INTO `industries` VALUES (1,'Accounting'),(2,'Administration'),(3,'Advertising'),(4,'Aerospace'),(5,'Agriculture'),(6,'Aircraft'),(7,'Airline'),(8,'Apparel & Accessories'),(9,'Art'),(10,'Automotive'),(11,'Aviation'),(12,'Banking'),(13,'Beauty & Cosmetology'),(14,'Biotechnology'),(15,'Broadcasting'),(16,'Brokerage'),(17,'Call Centers'),(18,'Cargo Handling'),(19,'Chemical'),(20,'Commercial Driving'),(21,'Computer'),(22,'Construction'),(23,'Consulting'),(24,'Consumer Products'),(25,'Cosmetics'),(26,'Customer Service'),(27,'Defense'),(28,'Department Stores'),(29,'Editing'),(30,'Education'),(31,'Electronics'),(32,'Energy'),(33,'Engineering'),(34,'Entertainment & Leisure'),(35,'Fabraction'),(36,'Financial'),(37,'Fitness'),(38,'Food Beverage'),(39,'Grocery'),(40,'Healthcare'),(41,'Information Technology'),(42,'Insurance'),(43,'Internet Publishing'),(44,'Investment Banking'),(45,'Legal'),(46,'Literacy'),(47,'Management'),(48,'Manufacturing'),(49,'Marketing'),(50,'Miscellaneous'),(51,'Motion Picture & Video'),(52,'Music'),(53,'Newspaper Publishers'),(54,'Nursing'),(55,'Online Editing'),(56,'Performance Art'),(57,'Pharmaceuticals'),(58,'Private Equity'),(59,'Professional'),(60,'Publishing'),(61,'Real Estate'),(62,'Retail'),(63,'Security'),(64,'Service'),(65,'Shipping'),(66,'Software'),(67,'Sports'),(68,'Technology'),(69,'Telecommunications'),(70,'Television'),(71,'Tobacco'),(72,'Trade'),(73,'Transportation'),(74,'Venture Capital'),(75,'Warehouse'),(76,'Wellness'),(77,'Wholesale');
/*!40000 ALTER TABLE `industries` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `pages`
--

DROP TABLE IF EXISTS `pages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pages` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `slug` varchar(150) NOT NULL,
  `title` varchar(255) NOT NULL,
  `body` text NOT NULL,
  `modules` varchar(255) NOT NULL,
  `updated` datetime NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`),
  UNIQUE KEY `slug` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `pages`
--

LOCK TABLES `pages` WRITE;
/*!40000 ALTER TABLE `pages` DISABLE KEYS */;
INSERT INTO `pages` VALUES (5,'testing','testing','<p><span style=\"font-weight: bold;\">This is a new page</span><br></p>','','2014-03-28 14:59:19','2014-03-28 21:59:02');
/*!40000 ALTER TABLE `pages` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `programs`
--

DROP TABLE IF EXISTS `programs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `programs` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider_id` int(11) DEFAULT NULL,
  `name` varchar(255) NOT NULL,
  `info` text NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `programs`
--

LOCK TABLES `programs` WRITE;
/*!40000 ALTER TABLE `programs` DISABLE KEYS */;
/*!40000 ALTER TABLE `programs` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers`
--

DROP TABLE IF EXISTS `providers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `info` longtext NOT NULL,
  `industry_id` int(11) NOT NULL,
  `visible` char(1) DEFAULT 'N',
  `tags` varchar(255) NOT NULL,
  `created` timestamp NOT NULL DEFAULT CURRENT_TIMESTAMP,
  `modifed` timestamp NOT NULL DEFAULT '0000-00-00 00:00:00',
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers`
--

LOCK TABLES `providers` WRITE;
/*!40000 ALTER TABLE `providers` DISABLE KEYS */;
INSERT INTO `providers` VALUES (2,'Samples','testing update and stuff and more and more stuff<br>',9,'Y','paints','2014-03-30 00:46:19','2014-04-03 03:15:40');
/*!40000 ALTER TABLE `providers` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `providers_locations`
--

DROP TABLE IF EXISTS `providers_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `providers_locations` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `provider_id` int(11) DEFAULT NULL,
  `address` varchar(255) DEFAULT NULL,
  `address2` varchar(255) DEFAULT NULL,
  `city` varchar(50) DEFAULT NULL,
  `state` varchar(3) DEFAULT NULL,
  `county` varchar(100) DEFAULT NULL,
  `zip` varchar(15) DEFAULT NULL,
  `email_public` varchar(100) DEFAULT NULL,
  `phone_public` varchar(45) DEFAULT NULL,
  `fax_public` varchar(45) DEFAULT NULL,
  `email_private` varchar(100) DEFAULT NULL,
  `phone_private` varchar(45) DEFAULT NULL,
  `fax_private` varchar(45) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `providers_locations`
--

LOCK TABLES `providers_locations` WRITE;
/*!40000 ALTER TABLE `providers_locations` DISABLE KEYS */;
/*!40000 ALTER TABLE `providers_locations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `account_id` int(10) NOT NULL DEFAULT '1',
  `username` varchar(100) NOT NULL,
  `password` varchar(40) NOT NULL,
  `salt` varchar(60) NOT NULL,
  `fname` varchar(70) NOT NULL,
  `lname` varchar(70) NOT NULL,
  `phone` varchar(20) NOT NULL,
  `email` varchar(150) NOT NULL,
  `status` varchar(255) NOT NULL,
  `position` varchar(255) NOT NULL,
  `role` int(11) NOT NULL DEFAULT '1',
  `cell` varchar(20) NOT NULL,
  `address` varchar(255) NOT NULL,
  `city` varchar(70) NOT NULL,
  `state` varchar(50) NOT NULL,
  `zip` varchar(15) NOT NULL,
  `bio` text NOT NULL,
  `last_log` datetime NOT NULL,
  `date_created` datetime NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (6,1,'scotty.dean','9215c4dd3f1c3dc175e5f897632f94ed2c39409e','82e38088148f964782d6','Scott','Dean','530 675 2785','scottyadean@gmail.com','','',2,'530 675 2785','123 main St.','Placerville','Ca','95667','','2014-03-27 21:03:16','2014-03-27 20:12:19');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2014-04-02 23:37:39
